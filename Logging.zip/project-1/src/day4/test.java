package day4;

import java.util.ArrayList;
import java.util.*;  

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub\
		
		ArrayList<Employee> empList = new ArrayList<Employee>();
		
		empList.add(new Employee(1,"John",10000D));
		empList.add(new Employee(2,"Mark",2000D));
		empList.add(new Employee(3,"Joseph",20000D));
		empList.add(new Employee(4,"Ron",50000D));
		empList.add(new Employee(5,"Jeck",5000D));
		empList.add(new Employee(6,"Jew",1000D));
		empList.add(new Employee(7,"Farhan",30000D));
		
		//iterating list with for loop
		for(Employee emp:empList)
		{
			System.out.println("List with for loop : "+emp);
		}
		
		//iterating list with for Each loop
		empList.forEach(emp->System.out.println(emp));
		
		//iterating thru stream
		empList.stream().forEach(System.out::println);
	
	   //iterate using iterator 
	    Iterator<Employee> itr = empList.iterator();
	    while(itr.hasNext())
	    {
	    	System.out.println("List with iterator "+itr.next());
	    }
	    
	    //sorting with id
	    Collections.sort(empList);    
	    
	    ListIterator<Employee> listItr = empList.listIterator();
	    while(listItr.hasPrevious())
	    {
	    	System.out.println("List in reverse order "+listItr.previous());
	    }
	}
}
