package day4;

public class Employee implements Comparable<Employee> {
	
	int empId;
	String empName;
	Double salary;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public Employee(int empId, String empName, Double salary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + "]";
	}
	@Override
	public int compareTo(Employee o) {
		if(this.empId==o.empId)
		{
			return 0;
		}
		else if(this.empId>o.empId)
		{
			return -1;
		}
		else if(this.empId<o.empId)
		{
			return 1;
		}
		return 0;
	}
	
}
