package myassignment;

import java.io.PrintStream;

public class Class1 {
	public static final Class2 class2 = new Class2();
	
	public void show()
	{
		System.out.println("class 1 show method");
	}

}
