package myassignment;

import java.io.PrintStream;

public class Class3 {
	
	public static final Class4 class4 = new Class4();

	public  void show()
	{
		System.out.println("class 3 show method");
	}
}
