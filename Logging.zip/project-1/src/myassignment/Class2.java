package myassignment;

import java.io.PrintStream;

public class Class2 {
	
	public static final Class3 class3 = new Class3();
	public void show()
	{
		System.out.println("class 2 show method");
	}
}
