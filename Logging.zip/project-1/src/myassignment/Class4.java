package myassignment;

import java.io.PrintStream;

public class Class4 {
    
	public void show()
	{
		System.out.println("class 4 show method");
	}
	public static void main(String[] args) {
		
		Class1.class2.class3.class4.show();

	}

}
